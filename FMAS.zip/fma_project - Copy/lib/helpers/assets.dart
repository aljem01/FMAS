class AppAsset {
  static const String houseSvg = "assets/House.svg";
  static const String countryUgandaSvg = "assets/Uganda.svg";
  static const String accountSvg = "assets/Account.svg";
}
